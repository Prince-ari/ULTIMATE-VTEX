import { ModuleStub } from "@/components/shell/ModuleStub"

export default function Page() {
  return (
    <ModuleStub
      kicker="Developers"
      title="Webhooks"
      description="URL qu'on notifie en temps réel quand un événement se produit sur ton compte."
      icon="hook"
      phase="3"
      outline={[
    "Ajouter un endpoint",
    "Sélectionner événements (payment.completed, invoice.paid…)",
    "Signature HMAC des payloads",
    "Historique livraisons + rejeux",
    "Alertes en cas d'échec répété",
    "Test manuel d'événement",
      ]}
    />
  )
}