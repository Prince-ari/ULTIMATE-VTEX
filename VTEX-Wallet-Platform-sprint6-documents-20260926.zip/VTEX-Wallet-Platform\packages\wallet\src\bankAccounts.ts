import { and, asc, eq } from "drizzle-orm"
import { VaultIntegrityError, VaultUnavailableError, ValidationError, bankAccounts, db, revealBankAccountIban, type Actor } from "@vtex/core"

/**
 * RIB d'un titulaire, tels qu'il les voit dans son Wallet : son RIB principal et ses sous-RIB ACTIFS, avec l'IBAN complet
 * (c'est précisément ce qu'il partage pour recevoir un virement). Lecture seule : rien ne se modifie depuis le Wallet.
 * Source de vérité unique : `bank_accounts` (le Dashboard écrit, le Wallet lit).
 */
export async function listMyBankAccounts(actor: Actor) {
  const rows = await db
    .select()
    .from(bankAccounts)
    .where(and(eq(bankAccounts.walletType, "PERSONAL"), eq(bankAccounts.holderId, actor.id), eq(bankAccounts.status, "active")))
    .orderBy(asc(bankAccounts.kind), asc(bankAccounts.createdAt))
  return rows.map((row) => {
    try {
      const { iban, ibanFormatted } = revealBankAccountIban(row)
      return { id: row.id, kind: row.kind, label: row.label, bankName: row.bankName, accountHolderName: row.accountHolderName, currency: row.currency, iban, ibanFormatted, bic: row.bic, ledgerAccountId: row.ledgerAccountId }
    } catch (error) {
      if (error instanceof VaultUnavailableError || error instanceof VaultIntegrityError) throw new ValidationError("Vos coordonnées bancaires sont momentanément indisponibles.")
      throw error
    }
  })
}
