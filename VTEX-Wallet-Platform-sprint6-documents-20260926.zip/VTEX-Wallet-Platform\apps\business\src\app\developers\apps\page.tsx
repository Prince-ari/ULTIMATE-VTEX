import { ModuleStub } from "@/components/shell/ModuleStub"

export default function Page() {
  return (
    <ModuleStub
      kicker="Developers"
      title="Applications"
      description="Applications tierces connectées à ton compte via OAuth ou clés directes."
      icon="apps"
      phase="3"
      outline={[
    "Liste apps installées",
    "Périmètre d'accès (scopes)",
    "Révocation d'accès",
    "Application publique : soumission à la marketplace",
    "Statistiques d'usage",
    "Audit des actions app",
      ]}
    />
  )
}